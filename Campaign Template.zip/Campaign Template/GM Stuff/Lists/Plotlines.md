# Plotlines

```dataview
list from "Plotlines"
```
