# Lists
 
 This folder will manage Mythic's lists. Thus, only the characters or plotlines that have actually appeared in game will be present here. I will also include other lists, like themes or Chekhov guns, for completeness.
 
 As locations have their own characters and plotlines, sometimes they will also intermingle with these lists. For instance, when rolling for a plotline in a random event in a specific location, I will include my existing plots list as well as the undiscovered plotlines in the location. That way, they will be brought up organically.
 
 
