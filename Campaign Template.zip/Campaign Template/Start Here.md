---
your banner here
---

# Campaign Name
Campaign description goes here...

## Rules
	- RPG ruleset:
	- GM Emulation:
	- Other resources: